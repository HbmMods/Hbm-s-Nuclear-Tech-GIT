package com.hbm.blocks;

public interface ISpotlight {

	public int getBeamLength();
}
