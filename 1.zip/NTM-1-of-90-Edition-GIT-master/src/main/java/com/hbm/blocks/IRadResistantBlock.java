package com.hbm.blocks;

public interface IRadResistantBlock {

	public int getResistance();
}
