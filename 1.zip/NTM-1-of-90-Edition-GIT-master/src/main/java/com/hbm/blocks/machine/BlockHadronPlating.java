package com.hbm.blocks.machine;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;

public class BlockHadronPlating extends Block {

	public BlockHadronPlating(Material mat) {
		super(mat);
	}
}
