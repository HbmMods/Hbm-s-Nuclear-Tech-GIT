package com.hbm.blocks.generic;

import net.minecraft.block.BlockLadder;

public class BlockNTMLadder extends BlockLadder {

	public BlockNTMLadder() {
		super();
	}
}
