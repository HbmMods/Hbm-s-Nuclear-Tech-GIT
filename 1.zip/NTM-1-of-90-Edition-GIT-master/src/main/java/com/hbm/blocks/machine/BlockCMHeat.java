package com.hbm.blocks.machine;

import net.minecraft.block.material.Material;

public class BlockCMHeat extends BlockPillar {
	
	public BlockCMHeat(Material mat, String top) {
		super(mat, top);
	}
}
