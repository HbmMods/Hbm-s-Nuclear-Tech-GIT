package com.hbm.blocks.machine;

import net.minecraft.block.material.Material;

public class BlockCMFlux extends BlockPillar {
	
	public BlockCMFlux(Material mat, String top) {
		super(mat, top);
	}
}
