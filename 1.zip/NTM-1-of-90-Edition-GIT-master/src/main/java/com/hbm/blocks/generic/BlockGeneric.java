package com.hbm.blocks.generic;

import com.hbm.blocks.BlockBase;

import net.minecraft.block.material.Material;

public class BlockGeneric extends BlockBase {

	public BlockGeneric(Material material) {
		super(material);
	}
}
