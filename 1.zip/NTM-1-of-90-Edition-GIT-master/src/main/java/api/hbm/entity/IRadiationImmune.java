package api.hbm.entity;

public interface IRadiationImmune { }
