package api.hbm.conveyor;

import net.minecraft.item.ItemStack;

public interface IConveyorPackage {

	public ItemStack[] getItemStacks();
}
