package api.hbm.conveyor;

import net.minecraft.item.ItemStack;

public interface IConveyorItem {

	public ItemStack getItemStack();
}
