package api.hbm.fluid;

import api.hbm.fluidmk2.IFluidConnectorBlockMK2;

@Deprecated
public interface IFluidConnectorBlock extends IFluidConnectorBlockMK2 { }
