package api.hbm.fluid;

@Deprecated
public interface IFluidStandardTransceiver extends IFluidStandardReceiver, IFluidStandardSender { }
