package api.hbm.fluid;

import api.hbm.fluidmk2.IFluidConnectorMK2;

@Deprecated
public interface IFluidConnector extends IFluidConnectorMK2 { }
