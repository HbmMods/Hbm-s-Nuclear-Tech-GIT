package api.hbm.redstoneoverradio;

public class RORFunctionException extends RuntimeException {

	public RORFunctionException(String message) {
		super(message);
	}
}
