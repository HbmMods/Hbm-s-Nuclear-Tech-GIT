package api.hbm.redstoneoverradio;

public interface IRORInfo {

	public static String PREFIX_VALUE =		"VAL:";
	public static String PREFIX_FUNCTION =	"FUN:";

	public String[] getFunctionInfo();
}
