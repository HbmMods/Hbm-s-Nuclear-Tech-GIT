package api.hbm.block;

public interface IPileNeutronReceiver {

	public void receiveNeutrons(int n);
}
