package api.hbm.fluidmk2;

public interface IFluidStandardTransceiverMK2 extends IFluidStandardReceiverMK2, IFluidStandardSenderMK2 {

}
