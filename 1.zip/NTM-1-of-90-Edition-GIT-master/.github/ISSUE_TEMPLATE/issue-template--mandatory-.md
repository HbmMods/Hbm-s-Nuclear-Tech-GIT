---
name: Issue template (mandatory)
about: Template for mod-related issues
title: ''
labels: ''
assignees: ''

---

### Describe the bug

Please describe the issue in as much detail as possible. Also mention the version of the mod you're running, if it's not the newest. In the case of a crash, please attach a crash log.
