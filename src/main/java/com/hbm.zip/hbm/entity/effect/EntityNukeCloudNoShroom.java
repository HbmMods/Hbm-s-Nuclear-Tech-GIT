package com.hbm.entity.effect;

import net.minecraft.world.World;

public class EntityNukeCloudNoShroom extends EntityNukeCloudSmall {

	public EntityNukeCloudNoShroom(World p_i1582_1_) {
		super(p_i1582_1_);
	}

	public EntityNukeCloudNoShroom(World p_i1582_1_, int maxAge) {
		super(p_i1582_1_, maxAge, 1.0F);
	}

}
