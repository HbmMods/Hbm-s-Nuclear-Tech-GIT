package com.hbm.calc;

public class EasyLocation {

	public double posX;
	public double posY;
	public double posZ;
	
	public EasyLocation(double x, double y, double z) {
		posX = x;
		posY = y;
		posZ = z;
	}
}
