package com.hbm.blocks.generic;

import net.minecraft.block.Block;
import net.minecraft.block.BlockStairs;

public class BlockPinkStairs extends BlockStairs {

	public BlockPinkStairs(Block p_i45428_1_, int p_i45428_2_) {
		super(p_i45428_1_, p_i45428_2_);
	}

}
